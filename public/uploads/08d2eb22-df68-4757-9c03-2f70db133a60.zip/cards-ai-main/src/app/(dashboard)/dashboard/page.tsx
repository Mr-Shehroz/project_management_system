"use client";

import { useEffect, useState } from "react";
import { CardTypeSelector, type CardType } from "@/components/CardTypeSelector";
import { StyleSelector, type CardStyle } from "@/components/StyleSelector";
import { ColorThemeSelector, type ColorTheme } from "@/components/ColorThemeSelector";
import { CustomColorPicker } from "@/components/CustomColorPicker";
import { CustomCardType, type ToneType } from "@/components/CustomCardType";
import { CustomMessageText } from "@/components/CustomMessageText";
import { PromptInput } from "@/components/PromptInput";
import { CardPreview } from "@/components/CardPreview";
import { ActionButtons } from "@/components/ActionButtons";
import { Button } from "@/components/ui/button";
import { Wand2 } from "lucide-react";
import { RecipientNameInput } from "@/components/RecipientNameInput";
import { composeImagePrompt } from "@/lib/prompt-composer";
import { downloadBase64Image, downloadImage } from "@/lib/download-image";
import { TemplateCardGenerator } from "@/components/TemplateCardGenerator";
import { ModeSelector, type GeneratorMode } from "@/components/ModeSelector";
import { Template } from "@/types/template";
import { toast } from "sonner";
import { generateCardFilename } from "@/lib/filename";

export default function Page() {
    const [mode, setMode] = useState<GeneratorMode>("template");
    const [cardType, setCardType] = useState<CardType>("birthday");
    const [style, setStyle] = useState<CardStyle>("modern");
    const [colorTheme, setColorTheme] = useState<ColorTheme>("pastel");
    const [prompt, setPrompt] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [previewUrl, setPreviewUrl] = useState<string | undefined>(undefined);

    // Custom color state
    const [primaryColor, setPrimaryColor] = useState("#6D28D9");
    const [secondaryColor, setSecondaryColor] = useState("#EC4899");
    const [accentColor, setAccentColor] = useState("#F59E0B");

    // Custom card type state
    const [customCardTitle, setCustomCardTitle] = useState("");
    const [customOccasion, setCustomOccasion] = useState("");
    const [customTone, setCustomTone] = useState<ToneType>("friendly");

    // Custom message state (available for all card types)
    const [includeCustomMessage, setIncludeCustomMessage] = useState(false);
    const [customMessageText, setCustomMessageText] = useState("");

    const canGenerate = prompt.trim().length > 0;

    const handleGenerate = async () => {
        setIsLoading(true);

        try {
            const res = await fetch("/api/generate", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    cardType,
                    recipientName,
                    style,
                    colorTheme,
                    primaryColor,
                    secondaryColor,
                    accentColor,
                    prompt,
                    customCardTitle,
                    customOccasion,
                    tone: customTone,
                    includeCustomMessage,
                    customMessageText,
                }),
            });

            const data = await res.json();

            if (!data.success) {
                toast.error("Generation failed!");
                throw new Error("Generation failed");
            }

            // ✅ FIX: read from data.card.imageUrl
            setPreviewUrl(data.card.imageUrl);
            toast.success("Card generated successfully!");
        } catch (err) {
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };



    // const handleDownload = () => {
    //     if (!previewUrl) return;
    //     downloadBase64Image(previewUrl, "cards-ai.png");
    //     toast.success("Image downloaded!");
    // };
    const handleDownload = (
  imageUrl: string,
  cardType: string,
  recipientName: string
) => {
    if (!previewUrl) return;
  const filename = generateCardFilename(cardType, recipientName);
  downloadImage(imageUrl, filename);
        toast.success("Image downloaded!");

};


    const handleRegenerate = () => {
        handleGenerate();
    };

    const handleReset = () => {
        setCardType("birthday");
        setStyle("modern");
        setColorTheme("pastel");
        setPrompt("");
        setPreviewUrl(undefined);

        setPrimaryColor("#6D28D9");
        setSecondaryColor("#EC4899");
        setAccentColor("#F59E0B");

        setCustomCardTitle("");
        setCustomOccasion("");
        setCustomTone("friendly");

        setIncludeCustomMessage(false);
        setCustomMessageText("");
    };

    //   recipient name useState
    const [recipientName, setRecipientName] = useState("");
    const finalPrompt = composeImagePrompt({
        cardType,
        recipientName,
        style,
        colorTheme,
        primaryColor,
        secondaryColor,
        accentColor,
        prompt,
        customCardTitle,
        customOccasion,
        tone: customTone,
        includeCustomMessage,
        customMessageText,
    });

    console.log(finalPrompt);

    const [templates, setTemplates] = useState<Template[]>([]);
    const [isLoadingTemplates, setIsLoadingTemplates] = useState(true);

    useEffect(() => {
        async function loadTemplates() {
            try {
                const categories = ["birthday", "wedding", "anniversary", "invitation"];
                const results = await Promise.all(
                    categories.map((c) =>
                        fetch(`/api/templates?category=${c}`).then((res) => res.json())
                    )
                );
                setTemplates(results.flat());
            } catch (error) {
                console.error("Failed to load templates", error);
            } finally {
                setIsLoadingTemplates(false);
            }
        }

        loadTemplates();
    }, []);


    return (
        <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12">
            {/* Page Header */}
            <div className="mb-6 text-center sm:mb-8">
                <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                    Generate Your Card
                </h1>
                <p className="mt-2 text-base text-muted-foreground sm:text-lg">
                    Create beautiful greeting cards in seconds
                </p>
            </div>

            {/* Mode Toggle */}
            <div className="mb-8">
                <ModeSelector mode={mode} onModeChange={setMode} />
            </div>

            {/* Template Mode */}
            {mode === "template" && <TemplateCardGenerator templates={templates}
                isTempLoading={isLoadingTemplates} />}

            {/* AI Generator Mode */}
            {mode === "ai" && (
                <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
                    {/* Left Column */}
                    <div className="space-y-6">
                        <div className="rounded-xl border bg-card p-5 shadow-card sm:p-6">
                            <div className="space-y-6">
                                <CardTypeSelector
                                    selected={cardType}
                                    onSelect={setCardType}
                                />

                                {cardType === "custom" && (
                                    <>
                                        <div className="h-px bg-border" />
                                        <CustomCardType
                                            cardTitle={customCardTitle}
                                            occasionDescription={customOccasion}
                                            tone={customTone}
                                            includeCustomMessage={includeCustomMessage}
                                            onCardTitleChange={setCustomCardTitle}
                                            onOccasionDescriptionChange={setCustomOccasion}
                                            onToneChange={setCustomTone}
                                            onIncludeCustomMessageChange={setIncludeCustomMessage}
                                        />
                                    </>
                                )}

                                <div className="h-px bg-border" />
                                <RecipientNameInput
                                    value={recipientName}
                                    onChange={setRecipientName}
                                />
                                <PromptInput
                                    value={prompt}
                                    onChange={setPrompt}
                                />

                                <div className="h-px bg-border" />

                                <CustomMessageText
                                    enabled={includeCustomMessage}
                                    message={customMessageText}
                                    onToggle={setIncludeCustomMessage}
                                    onMessageChange={setCustomMessageText}
                                />

                                <div className="h-px bg-border" />

                                <StyleSelector
                                    selected={style}
                                    onSelect={setStyle}
                                />

                                <div className="h-px bg-border" />

                                <ColorThemeSelector
                                    selected={colorTheme}
                                    onSelect={setColorTheme}
                                />

                                {colorTheme === "custom" && (
                                    <>
                                        <div className="h-px bg-border" />
                                        <CustomColorPicker
                                            primaryColor={primaryColor}
                                            secondaryColor={secondaryColor}
                                            accentColor={accentColor}
                                            onPrimaryChange={setPrimaryColor}
                                            onSecondaryChange={setSecondaryColor}
                                            onAccentChange={setAccentColor}
                                        />
                                    </>
                                )}
                            </div>
                        </div>

                        {/* Generate Button */}
                        <Button
                            variant="gradient"
                            size="xl"
                            className="w-full"
                            disabled={!canGenerate || isLoading}
                            onClick={handleGenerate}
                        >
                            <Wand2 className="h-5 w-5" />
                            {isLoading ? "Generating..." : "Generate Card"}
                        </Button>
                    </div>

                    {/* Right Column */}
                    <div className="space-y-4">
                        <div className="rounded-xl border bg-card p-5 shadow-card sm:p-6">
                            <CardPreview
                                imageUrl={previewUrl}
                                isLoading={isLoading}
                            />
                        </div>

                        <ActionButtons
                            hasPreview={!!previewUrl}
                            onDownload={() => handleDownload(
                                previewUrl || "",
                                cardType,
                                recipientName
                            )}
                            onRegenerate={handleRegenerate}
                            onReset={handleReset}
                        />
                    </div>
                </div>
            )}
        </main>
    )
}
