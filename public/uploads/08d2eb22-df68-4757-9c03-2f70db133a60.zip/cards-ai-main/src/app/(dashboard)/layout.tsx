import type { Metadata } from "next";
import { Toaster } from "@/components/ui/sonner"
import { TooltipProvider } from "@/components/ui/tooltip"
import { DashboardHeader } from "@/components/DashboardHeader";
import { Poppins } from "next/font/google";

// const geistSans = Geist({
//   variable: "--font-geist-sans",
//   subsets: ["latin"],
// });

const poppins = Poppins({
    variable: "--font-poppins",
    subsets: ["latin"],
    weight: ["400", "700"],
});

export const metadata: Metadata = {
    title: "Cards AI Dashboard",
    description: "AI-powered card generator",
};

export default function RootLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <TooltipProvider>
            <div className={`min-h-screen bg-background ${poppins.variable}`}>
                <DashboardHeader />
                {children}
            </div>
            <Toaster />
        </TooltipProvider>
    );
}
