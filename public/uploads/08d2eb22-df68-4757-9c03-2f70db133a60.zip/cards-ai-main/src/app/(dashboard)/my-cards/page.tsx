import { EmptyCardsState } from "@/components/EmptyCardsState";
import { requireUser } from "@/lib/auth";
import { db } from "@/db";
import { cards } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { MyCardsClient } from "@/components/MyCardsClient";

export default async function MyCardsPage() {
  const user = await requireUser();

  const userCards = await db
    .select()
    .from(cards)
    .where(eq(cards.userId, user.id))
    .orderBy(desc(cards.createdAt));

  const formattedCards = userCards.map((card) => ({
    id: card.id,
    imageUrl: card.imageUrl,
    cardType: card.cardType,
    recipientName: card.recipientName ?? "",
    createdAt: card.createdAt
    ? new Date(card.createdAt).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    : "",
}));

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold sm:text-3xl">My Cards</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          All your generated greeting cards in one place
        </p>
      </div>

      {formattedCards.length === 0 ? (
        <EmptyCardsState />
      ) : (
        <MyCardsClient cards={formattedCards} />
      )}
    </main>
  );
}
