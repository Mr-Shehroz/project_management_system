import NextAuth, { type AuthOptions } from "next-auth";
import Google from "next-auth/providers/google";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcrypt";

export const authOptions: AuthOptions = {
  providers: [
    Google({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
    Credentials({
      name: "Email & Password",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },

      async authorize(credentials) {
        if (!credentials?.email || !credentials.password) {
          throw new Error("Missing credentials");
        }

        const [user] = await db
          .select()
          .from(users)
          .where(eq(users.email, credentials.email));

        if (!user || !user.password) {
          throw new Error("Invalid email or password");
        }

        const isValid = await bcrypt.compare(
          credentials.password,
          user.password
        );

        if (!isValid) {
          throw new Error("Invalid email or password");
        }

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          image: user.image,
        };
      },
    }),
  ],
  
  session: {
    strategy: "jwt",
  },

  callbacks: {
  async signIn({ user, account }) {
    if (!user.email) return false;

    // ✅ Only auto-create users for OAuth providers
    if (account?.provider !== "credentials") {
      const existingUser = await db
        .select()
        .from(users)
        .where(eq(users.email, user.email));

      if (existingUser.length === 0) {
        await db.insert(users).values({
          id: user.id!,
          email: user.email,
          name: user.name,
          image: user.image,
        });
      }
    }

    return true;
  },
},

};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };