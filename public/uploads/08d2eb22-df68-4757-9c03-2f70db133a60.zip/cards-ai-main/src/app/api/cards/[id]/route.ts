import { NextRequest, NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { db } from "@/db";
import { cards } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { deleteCloudinaryImage } from "@/lib/cloudinary";
import { extractCloudinaryPublicId } from "@/lib/cloudinary-utils";

export async function DELETE(
  _req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireUser();
    const { id: cardId } = await context.params;

    // 1️⃣ Fetch card
    const [card] = await db
      .select()
      .from(cards)
      .where(and(eq(cards.id, cardId), eq(cards.userId, user.id)));

    if (!card) {
      return NextResponse.json({ success: false }, { status: 404 });
    }

    // 2️⃣ Delete image from Cloudinary (if valid)
    const publicId = extractCloudinaryPublicId(card.imageUrl);
    if (publicId) {
      await deleteCloudinaryImage(publicId);
    }

    // 3️⃣ Delete DB record
    await db
      .delete(cards)
      .where(and(eq(cards.id, cardId), eq(cards.userId, user.id)));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete card error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to delete card" },
      { status: 500 }
    );
  }
}
