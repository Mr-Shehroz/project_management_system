// app/api/cards/template/route.ts
import { NextResponse } from "next/server";
import { uploadTemplateCard } from "@/lib/upload-template-card";
import { createCard } from "@/db/actions";
import { requireUser } from "@/lib/auth";

export async function POST(req: Request) {
  const user = await requireUser();
  const body = await req.json();

  const imageUrl = await uploadTemplateCard(body.image);

  const card = await createCard({
    userId: user.id,
    imageUrl,
    cardType: body.cardType,
    recipientName: body.recipientName,
    prompt: body.message,
    // templateId: body.templateId, no need to store templateId for generated cards
  });

  return NextResponse.json({ success: true, card });
}
