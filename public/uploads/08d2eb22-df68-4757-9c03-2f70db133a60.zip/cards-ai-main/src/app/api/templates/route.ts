import { NextResponse } from "next/server";
import "server-only";
import { v2 as cloudinary } from "cloudinary";
import { Template } from "@/types/template";

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME!,
  api_key: process.env.CLOUDINARY_API_KEY!,
  api_secret: process.env.CLOUDINARY_API_SECRET!,
});

interface CloudinaryResource {
  public_id: string;
  secure_url: string;
  context?: {
    caption?: string;
  };
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");

    if (!category) {
      return NextResponse.json(
        { error: "Category required" },
        { status: 400 }
      );
    }

    const result = await cloudinary.search
      .expression(`folder:cards-ai/templates/${category}`) // Fixed: removed backtick before .expression
      .with_field("context")
      .with_field("metadata")
      .sort_by("public_id", "asc")
      .max_results(30)
      .execute();

    const templates: Template[] = result.resources.map((item: CloudinaryResource) => {

      return {
        id: item.public_id,
        name: item.context?.caption || "Untitled",
        thumbnail: item.secure_url,
        category,
      };
    });
    return NextResponse.json(templates);

  } catch (error) {
    console.error("Error fetching templates:", error);
    return NextResponse.json(
      { error: "Failed to fetch templates" },
      { status: 500 }
    );
  }
}