import { Button } from "@/components/ui/button";
import { Download, RefreshCw, RotateCcw } from "lucide-react";

interface ActionButtonsProps {
  hasPreview: boolean;
  onDownload: () => void;
  onRegenerate: () => void;
  onReset: () => void;
}

export function ActionButtons({ hasPreview, onDownload, onRegenerate, onReset }: ActionButtonsProps) {
  return (
    <div className="flex flex-wrap gap-2">
      <Button
        variant="outline"
        size="sm"
        onClick={onDownload}
        disabled={!hasPreview}
        className="flex-1 sm:flex-none"
      >
        <Download className="h-4 w-4" />
        Download
      </Button>
      <Button
        variant="outline"
        size="sm"
        onClick={onRegenerate}
        disabled={!hasPreview}
        className="flex-1 sm:flex-none"
      >
        <RefreshCw className="h-4 w-4" />
        Regenerate
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={onReset}
        className="flex-1 sm:flex-none"
      >
        <RotateCcw className="h-4 w-4" />
        Reset
      </Button>
    </div>
  );
}
