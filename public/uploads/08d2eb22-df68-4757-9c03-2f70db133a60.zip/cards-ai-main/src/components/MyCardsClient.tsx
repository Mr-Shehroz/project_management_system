"use client";

import { CardItem } from "@/components/CardItem";
import { downloadImage } from "@/lib/download-image";
import { generateCardFilename } from "@/lib/filename";
import { useState } from "react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";


interface Card {
  id: string;
  imageUrl: string;
  cardType: string;
  recipientName: string;
  createdAt: string;
}

export function MyCardsClient({ cards }: { cards: Card[] }) {
  const router = useRouter();
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  
  const handleDeleteConfirmed = async () => {
  if (!deleteId) return;

  try {
    setIsDeleting(true);

    const res = await fetch(`/api/cards/${deleteId}`, {
      method: "DELETE",
    });

    if (!res.ok) {
      throw new Error("Failed to delete");
    }

    toast.success("Card deleted successfully!");
    setDeleteId(null);

    // ✅ Better UX than reload (optional)
    router.refresh(); // if using App Router
    // window.location.reload();
  } catch {
    toast.error("Failed to delete card");
  } finally {
    setIsDeleting(false);
  }
};


  const handleDownload = (
  imageUrl: string,
  cardType: string,
  recipientName: string
) => {
  const filename = generateCardFilename(cardType, recipientName);
  downloadImage(imageUrl, filename);
  toast.success("Image downloaded!");
};

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {cards.map((card) => (
        <CardItem
          key={card.id}
          id={card.id}
          imageUrl={card.imageUrl}
          cardType={card.cardType}
          recipientName={card.recipientName}
          createdAt={card.createdAt}
          onDelete={() => setDeleteId(card.id)}
          onDownload={() => handleDownload(card.imageUrl, card.cardType, card.recipientName)}
        />
      ))}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
  <AlertDialogContent>
    <AlertDialogHeader>
      <AlertDialogTitle>Delete card?</AlertDialogTitle>
      <AlertDialogDescription>
        This action cannot be undone. The card will be permanently removed
        from your account.
      </AlertDialogDescription>
    </AlertDialogHeader>

    <AlertDialogFooter>
      <AlertDialogCancel disabled={isDeleting}>
        Cancel
      </AlertDialogCancel>
      <AlertDialogAction
        onClick={handleDeleteConfirmed}
        disabled={isDeleting}
        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
      >
        {isDeleting ? "Deleting..." : "Delete"}
      </AlertDialogAction>
    </AlertDialogFooter>
  </AlertDialogContent>
</AlertDialog>

    </div>
  );
}
