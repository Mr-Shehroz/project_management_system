"use client";

import { useRef } from "react";
import { cn } from "@/lib/utils";
import { Upload, User, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PhotoUploaderProps {
  photoUrl: string | null;
  onPhotoChange: (url: string | null) => void;
}

export function PhotoUploader({ photoUrl, onPhotoChange }: PhotoUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      onPhotoChange(url);
    }
  };

  const handleRemove = () => {
    onPhotoChange(null);
    if (inputRef.current) {
      inputRef.current.value = "";
    }
  };

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-foreground">
        Upload Your Photo
      </label>
      <div className="flex items-center gap-4">
        <div
          className={cn(
            "relative flex h-20 w-20 items-center justify-center overflow-hidden rounded-full border-2 border-dashed",
            "bg-muted transition-colors",
            photoUrl ? "border-primary" : "border-border"
          )}
        >
          {photoUrl ? (
            <>
              <img
                src={photoUrl}
                alt="Uploaded photo"
                className="h-full w-full object-cover"
              />
              <button
                type="button"
                onClick={handleRemove}
                className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-destructive-foreground shadow-sm transition-transform hover:scale-110"
              >
                <X className="h-3 w-3" />
              </button>
            </>
          ) : (
            <User className="h-8 w-8 text-muted-foreground" />
          )}
        </div>
        <div className="flex flex-col gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => inputRef.current?.click()}
            className="gap-2"
          >
            <Upload className="h-4 w-4" />
            {photoUrl ? "Change Photo" : "Upload Photo"}
          </Button>
          <p className="text-xs text-muted-foreground">
            JPG, PNG up to 5MB
          </p>
        </div>
        <input
          ref={inputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={handleFileChange}
          className="hidden"
        />
      </div>
    </div>
  );
}
