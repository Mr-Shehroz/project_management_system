"use client";

import { useState } from "react";
import { Download, RotateCcw, Save, Wand2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CardTypeSelector, type CardType } from "./CardTypeSelector";
import { TemplateGrid, type Template } from "./TemplateGrid";
import { PhotoUploader } from "./PhotoUploader";
import { TemplatePreview } from "./TemplatePreview";
import { toast } from "sonner";

const MAX_MESSAGE_LENGTH = 200;

interface TemplateCardGeneratorProps {
  templates: Template[];
  isTempLoading: boolean;
}


export function TemplateCardGenerator({
  templates,
  isTempLoading,
}: TemplateCardGeneratorProps) {
  const [cardType, setCardType] = useState<CardType>("birthday");
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [recipientName, setRecipientName] = useState("");
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isGenerated, setIsGenerated] = useState(false);
  const [finalImage, setFinalImage] = useState<string | null>(null);


  const canGenerate = selectedTemplate && recipientName.trim() && message.trim();

  const MAX_RECIPIENT_LENGTH = 25;

  const handleCardTypeChange = (newType: CardType) => {
    setCardType(newType);
    setSelectedTemplate(null);
    setIsGenerated(false);
  };

  const handleTemplateSelect = (template: Template) => {
    setSelectedTemplate(template);
    setIsGenerated(false);
  };

  const handleGenerate = async () => {
    if (!canGenerate) return;

    setIsLoading(true);
    // Simulate generation delay
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setIsLoading(false);
    setIsGenerated(true);
    toast.success("Card generated successfully!");
  };

  const handleSave = async () => {
  if (!finalImage || !selectedTemplate) return;

  const res = await fetch("/api/cards/generated", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      image: finalImage,
      cardType,
      recipientName,
      message,
    }),
  });

  if (!res.ok) {
    toast.error("Failed to save card");
    return;
  }

  toast.success("Card saved to My Cards!");
};


  const handleDownload = () => {
  if (!finalImage) return;

  const link = document.createElement("a");
  link.href = finalImage;
  link.download = `${recipientName || "card"}-${cardType}.png`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  toast.success("Image downloaded!");
};

  const handleReset = () => {
    setSelectedTemplate(null);
    setPhotoUrl(null);
    setRecipientName("");
    setMessage("");
    setIsGenerated(false);
  };

  const filteredTemplates = templates.filter(
    (t) => t.category === (cardType === "custom" ? "birthday" : cardType)
  );


  return (
    <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
      {/* Left Column - Inputs */}
      <div className="space-y-6">
        {/* Card Container - matching AI Generator style */}
        <div className="rounded-xl border border-border bg-card p-5 shadow-card sm:p-6">
          <div className="space-y-6">
            {/* Card Type Selector - reusing AI Generator component */}
            <CardTypeSelector
              selected={cardType}
              onSelect={handleCardTypeChange}
            />

            <div className="h-px bg-border" />

            {/* Template Grid */}
            {isTempLoading ? (
              <div className="text-sm text-muted-foreground">
                Loading templates…
              </div>
            ) : (
              <TemplateGrid
                templates={filteredTemplates}
                selectedId={selectedTemplate?.id ?? null}
                onSelect={handleTemplateSelect}
              />
            )}

            <div className="h-px bg-border" />

            {/* Photo Uploader */}
            <PhotoUploader
              photoUrl={photoUrl}
              onPhotoChange={setPhotoUrl}
            />

            <div className="h-px bg-border" />

            {/* Recipient Name */}
            <div className="space-y-2">
              <label
                htmlFor="recipient-name"
                className="text-sm font-medium text-foreground"
              >
                Recipient Name
              </label>
              <Input
                id="recipient-name"
                type="text"
                placeholder="e.g. Sarah, Ali & Ayesha, Team Marketing"
                value={recipientName}
                maxLength={MAX_RECIPIENT_LENGTH}
                onChange={(e) =>
                  setRecipientName(e.target.value.slice(0, MAX_RECIPIENT_LENGTH))
                }
              />
              <p className="text-xs text-muted-foreground">
                This name will appear on the card
              </p>
            </div>

            <div className="h-px bg-border" />

            {/* Message */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label
                  htmlFor="message"
                  className="text-sm font-medium text-foreground"
                >
                  Message
                </label>
                <span className="text-xs text-muted-foreground">
                  {message.length}/{MAX_MESSAGE_LENGTH}
                </span>
              </div>
              <Textarea
                id="message"
                placeholder="Wishing you a day filled with love and happiness..."
                value={message}
                onChange={(e) =>
                  setMessage(e.target.value.slice(0, MAX_MESSAGE_LENGTH))
                }
                rows={4}
                className="resize-none"
              />
            </div>
          </div>
        </div>

        {/* Generate Button - matching AI Generator gradient style */}
        <Button
          variant="gradient"
          size="xl"
          className="w-full"
          onClick={handleGenerate}
          disabled={!canGenerate || isLoading}
        >
          <Wand2 className="h-5 w-5" />
          {isLoading ? "Generating..." : "Generate Card"}
        </Button>
      </div>

      {/* Right Column - Preview */}
      <div className="space-y-4">
        {/* Preview Container - matching AI Generator style */}
        <div className="rounded-xl border border-border bg-card p-5 shadow-card sm:p-6">
          <TemplatePreview
            template={selectedTemplate}
            recipientName={recipientName}
            message={message}
            photoUrl={photoUrl}
            isGenerated={isGenerated}
            isLoading={isLoading}
            onPreviewReady={setFinalImage}
          />
        </div>

        {/* Action Buttons - matching AI Generator ActionButtons style */}
        {isGenerated && (
          <div className="flex flex-wrap gap-3">
            <Button onClick={handleSave} variant="outline" className="gap-2">
              <Save className="h-4 w-4" />
              Save Card
            </Button>
            <Button onClick={handleDownload} variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Download Image
            </Button>
            <Button
              onClick={handleReset}
              variant="ghost"
              className="gap-2 text-muted-foreground"
            >
              <RotateCcw className="h-4 w-4" />
              Reset
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
