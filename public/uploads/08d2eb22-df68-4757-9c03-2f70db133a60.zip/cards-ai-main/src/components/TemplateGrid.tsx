import { cn } from "@/lib/utils";
import { Check } from "lucide-react";
import type { CardType } from "./CardTypeSelector";

export interface Template {
  id: string;
  name: string;
  thumbnail: string;
  category: Exclude<CardType, "custom">;
}

// const templates: Template[] = [
//   // Birthday
//   { id: "bday-1", name: "Balloons & Confetti", thumbnail: "/placeholder.svg", category: "birthday" },
//   { id: "bday-2", name: "Cake Celebration", thumbnail: "/placeholder.svg", category: "birthday" },
//   { id: "bday-3", name: "Minimal Wishes", thumbnail: "/placeholder.svg", category: "birthday" },
//   // Wedding
//   { id: "wed-1", name: "Floral Elegance", thumbnail: "/placeholder.svg", category: "wedding" },
//   { id: "wed-2", name: "Gold & White", thumbnail: "/placeholder.svg", category: "wedding" },
//   { id: "wed-3", name: "Modern Minimal", thumbnail: "/placeholder.svg", category: "wedding" },
//   // Anniversary
//   { id: "ann-1", name: "Hearts & Love", thumbnail: "/placeholder.svg", category: "anniversary" },
//   { id: "ann-2", name: "Golden Years", thumbnail: "/placeholder.svg", category: "anniversary" },
//   { id: "ann-3", name: "Romantic Roses", thumbnail: "/placeholder.svg", category: "anniversary" },
//   // Invitation
//   { id: "inv-1", name: "Classic Formal", thumbnail: "/placeholder.svg", category: "invitation" },
//   { id: "inv-2", name: "Party Vibes", thumbnail: "/placeholder.svg", category: "invitation" },
//   { id: "inv-3", name: "Elegant Script", thumbnail: "/placeholder.svg", category: "invitation" },
// ];

interface TemplateGridProps {
  templates: Template[];
  selectedId: string | null;
  onSelect: (template: Template) => void;
}

export function TemplateGrid({ templates, selectedId, onSelect }: TemplateGridProps) {
  function truncateToTwoWords(text: string) {
    const words = text.trim().split(/\s+/);
    if (words.length <= 2) return text;
    return `${words.slice(0, 2).join(" ")}…`;
  }

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-foreground">
        Select Template
      </label>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {templates.map((template) => (
          <button
            key={template.id}
            type="button"
            onClick={() => onSelect(template)}
            className={cn(
              "group relative overflow-hidden rounded-xl border-2 bg-card transition-all duration-200",
              "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
              selectedId === template.id
                ? "border-primary shadow-md"
                : "border-border hover:border-muted-foreground/30 hover:shadow-sm"
            )}
          >
            <div className="aspect-4/5 w-full overflow-hidden bg-muted">
              <img
                src={template.thumbnail}
                alt={template.name}
                className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-105"
              />
            </div>
            <div className="p-2 text-center">
              <span
                className="block text-xs font-medium text-foreground text-center truncate"
                title={template.name} // optional: full title on hover
              >
                {truncateToTwoWords(template.name)}
              </span>
            </div>
            {selectedId === template.id && (
              <div className="absolute right-2 top-2 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-sm">
                <Check className="h-3 w-3" />
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
