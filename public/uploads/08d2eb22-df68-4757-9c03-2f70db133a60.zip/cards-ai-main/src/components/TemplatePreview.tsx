"use client";

import { ImageIcon } from "lucide-react";
import type { Template } from "./TemplateGrid";
import { useEffect, useRef, useState } from "react";

interface TemplatePreviewProps {
  template: Template | null;
  recipientName: string;
  message: string;
  photoUrl: string | null;
  isGenerated: boolean;
  isLoading: boolean;
  onPreviewReady?: (dataUrl: string) => void;
}

export function TemplatePreview({
  template,
  recipientName,
  message,
  photoUrl,
  isGenerated,
  isLoading,
  onPreviewReady,
}: TemplatePreviewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!template) return;

    const generatePreview = async () => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      try {
        // Set canvas size (1080x1350 - Instagram portrait)
        canvas.width = 1080;
        canvas.height = 1350;

        // Load template background
        const templateImg = new Image();
        templateImg.crossOrigin = "anonymous";

        await new Promise<void>((resolve, reject) => {
          templateImg.onload = () => resolve();
          templateImg.onerror = reject;
          templateImg.src = template.thumbnail;
        });

        // Draw template
        ctx.drawImage(templateImg, 0, 0, canvas.width, canvas.height);

        // Draw user photo if provided (NO BORDER - just the circle)
        if (photoUrl) {
          const photoImg = new Image();
          photoImg.crossOrigin = "anonymous";

          await new Promise<void>((resolve, reject) => {
            photoImg.onload = () => resolve();
            photoImg.onerror = reject;
            photoImg.src = photoUrl;
          });

          // Photo properties - adjusted to match your template exactly
          const photoSize = 500; // Slightly smaller to fit better
          const photoX = canvas.width / 2;
          const photoY = 700; // Moved up to match your template

          // Clip and draw photo (NO BORDER)
          ctx.save();
          ctx.beginPath();
          ctx.arc(photoX, photoY, photoSize / 2, 0, Math.PI * 2);
          ctx.clip();

          // Calculate scale to cover circle
          const scale = Math.max(
            photoSize / photoImg.width,
            photoSize / photoImg.height
          );
          const scaledWidth = photoImg.width * scale;
          const scaledHeight = photoImg.height * scale;
          const offsetX = photoX - scaledWidth / 2;
          const offsetY = photoY - scaledHeight / 2;

          ctx.drawImage(photoImg, offsetX, offsetY, scaledWidth, scaledHeight);
          ctx.restore();
        }

        // Draw recipient name (below photo, no background)
        if (recipientName.trim()) {
          ctx.font = "bold 50px poppins, sans-serif";
          ctx.fillStyle = "#FFFFFF";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";

          // Text shadow for visibility
          // ctx.shadowColor = "rgba(0, 0, 0, 0.6)";
          // ctx.shadowBlur = 12;
          // ctx.shadowOffsetX = 2;
          // ctx.shadowOffsetY = 20;

          ctx.fillText(recipientName.toUpperCase(), canvas.width / 2, 980);

          // Reset shadow
          ctx.shadowColor = "transparent";
          ctx.shadowBlur = 0;
          ctx.shadowOffsetX = 0;
          ctx.shadowOffsetY = 0;
        }

        // Draw message (below name, no background, word wrap)
        if (message.trim()) {
          ctx.font = "28px Arial, sans-serif";
          ctx.fillStyle = "#FFFFFF";
          ctx.textAlign = "center";

          // Add subtle shadow for message too
          // ctx.shadowColor = "rgba(0, 0, 0, 0.4)";
          // ctx.shadowBlur = 8;
          // ctx.shadowOffsetX = 1;
          // ctx.shadowOffsetY = 1;

          const maxWidth = 650;
          const lineHeight = 40;
          const words = message.split(" ");
          let line = "";
          let y = 1035;

          for (let i = 0; i < words.length; i++) {
            const testLine = line + words[i] + " ";
            const metrics = ctx.measureText(testLine);

            if (metrics.width > maxWidth && i > 0) {
              ctx.fillText(line, canvas.width / 2, y);
              line = words[i] + " ";
              y += lineHeight;
            } else {
              line = testLine;
            }
          }
          ctx.fillText(line, canvas.width / 2, y);

          // Reset shadow
          ctx.shadowColor = "transparent";
          ctx.shadowBlur = 0;
          ctx.shadowOffsetX = 0;
          ctx.shadowOffsetY = 0;
        }

        // Convert to data URL
        const dataUrl = canvas.toDataURL("image/png");
        setPreviewUrl(dataUrl);
        onPreviewReady?.(dataUrl);
      } catch (error) {
        console.error("Error generating preview:", error);
        setPreviewUrl(null);
      }
    };

    generatePreview();
  }, [template, recipientName, message, photoUrl]);

  return (
    <div className="space-y-3">
      <label className="text-sm font-medium text-foreground">
        Card Preview
      </label>

      <div className="relative aspect-4/5 w-full overflow-hidden rounded-lg border border-border bg-muted/30">
        {isLoading ? (
          <div className="flex h-full flex-col items-center justify-center gap-4">
            <div className="relative">
              <div className="h-16 w-16 animate-pulse rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
              </div>
            </div>
            <div className="space-y-2 text-center">
              <p className="text-sm font-medium text-foreground">
                Generating your card...
              </p>
              <p className="text-xs text-muted-foreground">
                This may take a moment
              </p>
            </div>
          </div>
        ) : previewUrl ? (
          <div className="relative h-full w-full">
            <img
              src={previewUrl}
              alt="Card preview"
              className="h-full w-full object-cover"
            />
            {isGenerated && (
              <div className="absolute bottom-3 right-3 rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground shadow-sm">
                Generated
              </div>
            )}
          </div>
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-4 text-muted-foreground">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-muted">
              <ImageIcon className="h-8 w-8" />
            </div>
            <div className="text-center">
              <p className="text-sm font-medium">Select a template</p>
              <p className="mt-1 text-xs">
                Choose a template and enter details to see preview
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Hidden canvas for generation */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}