import { db } from "@/db";
import { cards } from "@/db/schema";
import { nanoid } from "nanoid";

export async function createCard(data: {
  userId: string;
  imageUrl: string;
  prompt: string;
  cardType: string;
  recipientName?: string;
}) {
  const card = {
    id: nanoid(),
    ...data,
  };

  await db.insert(cards).values(card);
  return card;
}
