import {
  pgTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: text("id").primaryKey(), // from Auth.js
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  password: text("password"),
  image: text("image"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const cards = pgTable("cards", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id),
  imageUrl: text("image_url").notNull(),
  prompt: text("prompt").notNull(),
  cardType: varchar("card_type", { length: 50 }).notNull(),
  recipientName: varchar("recipient_name", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow(),
});
