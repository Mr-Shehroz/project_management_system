import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

export default withAuth(
  function middleware(req) {
    return NextResponse.next();
  },
  {
    callbacks: {
      authorized: ({ token }) => {
        // token exists = authenticated
        return !!token;
      },
    },
    pages: {
      signIn: "/login",
    },
  }
);

// ✅ Define protected routes here
export const config = {
  matcher: [
    "/dashboard/:path*",
    "/my-cards/:path*",
    "/api/cards/:path*",
    "/api/generate/:path*",
  ],
};
