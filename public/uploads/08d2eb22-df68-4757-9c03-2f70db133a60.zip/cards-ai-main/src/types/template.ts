import type { CardType } from "@/components/CardTypeSelector";

export interface Template {
  id: string;
  name: string;
  thumbnail: string;
  category: Exclude<CardType, "custom">;
}
